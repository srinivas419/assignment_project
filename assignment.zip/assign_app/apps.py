from django.apps import AppConfig


class AssignAppConfig(AppConfig):
    name = 'assign_app'
