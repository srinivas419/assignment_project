from django.db import models

# Create your models here.

class courses_table(models.Model):
    c_id = models.IntegerField(primary_key = True)
    c_name = models.CharField(max_length = 50)
    c_fee = models.IntegerField()
    c_duration = models.CharField(max_length=50)



